
INSERT INTO users (email, password) VALUES ('test@example.com', '123456');
SELECT * FROM users;
